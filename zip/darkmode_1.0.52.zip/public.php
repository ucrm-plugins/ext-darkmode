<?php /** @noinspection PhpUnhandledExceptionInspection */
// This Plugin does nothing when scheduled or manually executed!

require_once __DIR__."/vendor/autoload.php";

use League\Container\Container;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;
use SpaethTech\UCRM\SDK\LogLevel;
use SpaethTech\UCRM\SDK\Plugin;
use SpaethTech\UCRM\SDK\PluginConfig;
use SpaethTech\UCRM\SDK\PluginManifest;
use SpaethTech\UCRM\SDK\UcrmDatabase;


$container = new Container();
$container->add(LoggerInterface::class, Logger::class)
    ->addArguments(["plugin", [ new StreamHandler("data/plugin.log") ]]);

//Plugin::stderrToLog();
$plugin = new Plugin($container);
$logger = $plugin->getLogger();

$logger->info("Testing");

$manifest = $plugin->getManifest();
$test = $manifest->get("information.name");
var_dump($test);

$config = $plugin->getConfig();
$test = $config->get("logErrors");
//var_dump($test);
//$config->set("logErrors", true);
//$config->save();

$ucrm = $plugin->getUcrm();
$test = $ucrm->get("ucrmPublicUrl");
//var_dump($test);

$parameters = $plugin->getServerParameters();
$test = $parameters->get();
//var_dump($test);

$version = $plugin->getServerVersion();
$test = $version->get();
//var_dump($test);

