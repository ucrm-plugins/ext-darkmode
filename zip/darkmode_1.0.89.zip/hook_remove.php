<?php /** @noinspection DuplicatedCode */
declare(strict_types=1);

// Execute hook_disable.php, in case the user did not disable the Plugin before deleting!
require_once __DIR__."/hook_disable.php";

