# ext-darkmode
A super-simple dark mode plugin for UCRM.
