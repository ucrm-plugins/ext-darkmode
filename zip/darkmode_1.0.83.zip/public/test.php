<?php
declare(strict_types=1);

echo "TESTING SCRIPT!";
