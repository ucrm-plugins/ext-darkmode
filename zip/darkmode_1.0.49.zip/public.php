<?php /** @noinspection PhpUnhandledExceptionInspection */
// This Plugin does nothing when scheduled or manually executed!

require_once __DIR__."/vendor/autoload.php";

use SpaethTech\UCRM\SDK\LogLevel;
use SpaethTech\UCRM\SDK\Plugin;
use SpaethTech\UCRM\SDK\PluginConfig;
use SpaethTech\UCRM\SDK\PluginManifest;
use SpaethTech\UCRM\SDK\UcrmDatabase;

//Plugin::stderrToLog();
$plugin = new Plugin();
$logger = $plugin->getLogger();

$logger->info("Testing");

$manifest = $plugin->getManifest();
$test = $manifest->get("information.name");
var_dump($test);

$config = $plugin->getConfig();
$test = $config->get("logErrors");
var_dump($test);

$ucrm = $plugin->getUcrm();
$test = $ucrm->get("ucrmPublicUrl");
var_dump($test);


$parameters = $plugin->getUcrmParameters();
$test = $parameters->get();
var_dump($test);

//Plugin::initialize(__DIR__);
//var_dump($plugin->getDataPath());
//$plugin->logClear();
//$plugin->log(LogLevel::INFO, [ "name", "Testing"]);
//var_dump(getcwd());
//$test = Plugin::path("/usr/src/ucrm");
//var_dump($test);


//$test = PluginManifest::get("information.name");
//var_dump($test);

//$test = PluginConfig::get();
//var_dump($test);

//$test = PluginConfig::get();
//var_dump($test);

//$test = UcrmDatabase::query("SELECT * from app_key");
//var_dump($test);



//
//var_dump(PLUGIN_DIR);
//var_dump($plugin->getDataPath());
//
//var_dump(UcrmParameters::get("secret"));
//var_dump(PluginManifest::get("information.name"));
////Logger::debugPlugin(Manifest::get("information"));
//var_dump(PluginManifest::get("information"));
//var_dump(PluginConfig::get());
//
////var_dump($plugin->getCryptoKey()->saveToAsciiSafeString());
//var_dump($plugin->getMode());
//
//var_dump(PluginUcrm::get("pluginAppKey"));
//var_dump(UcrmVersion::get("version"));
//
//$db = new PluginDatabase();
//$pdo = $db->connect();
//$permissions = $db->permissions();
//var_dump($permissions);
//
//$pdo = UcrmDatabase::connect();

//$test = UcrmDatabase::query("SELECT * FROM app_key WHERE name = 'plugin_darkmode'");
//$test = UcrmDatabase::select("app_key", [ "name", "type", "plugin_id" ]);
//$test = AppKeyTable::all();
//$test = OptionTable::all();

//$test = OptionTable::where("option_id = 4");
///** @var OptionCollection $test */
//$options = OptionTable::where("option_id >= 4 and option_id <= 6");
//var_dump($options->each(fn($o) => print_r($o)));
//var_dump($options);

//$collection = new Collection([ "a", "b" ]);
//var_dump($collection);

