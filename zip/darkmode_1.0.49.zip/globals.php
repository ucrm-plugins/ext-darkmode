<?php
declare(strict_types=1);

if (!defined("PLUGIN_DIR"))
    define("PLUGIN_DIR", realpath(__DIR__));
