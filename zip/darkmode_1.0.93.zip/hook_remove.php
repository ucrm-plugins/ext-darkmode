<?php
// Execute hook_disable.php, in case the user did not disable the Plugin before deleting!
require_once __DIR__."/hook_disable.php";

